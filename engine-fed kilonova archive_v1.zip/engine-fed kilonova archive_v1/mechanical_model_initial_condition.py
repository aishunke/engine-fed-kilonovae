#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar 13 14:44:41 2021

@author: shunkeai
"""

import numpy as np

#constant
ccont=2.99*10**10
mp=1.67352e-24
Msun = 2.0e33
a = 7.5657e-15
h = 6.63e-27
kb=1.38*10**(-23)*10**7
sigmaT=6.652*10**(-25)
sigmaB=5.670373*10**(-5)
pi=np.pi

# function to calculate the number density of unshocked wind 
def unshocked_wind(L_sd, Gamma_w, r, sigma):
    v_w = np.sqrt(1-1/Gamma_w**2)*ccont
    rho_w = L_sd/(4*pi*r**2*v_w*Gamma_w**2*ccont**2)/(1+sigma)
    n_w = rho_w / mp 
    return n_w

def gamma2beta(gamma):
    beta=np.sqrt(1-1/gamma**2)
    return beta

def beta2gamma(beta):
    gamma=np.sqrt(1/(1-beta**2))
    return gamma

# function to solve the shock jump condition
def fgeneral(u_2s,gamma21,Gamma,sigma):
    x=u_2s**2

    A = Gamma*(2-Gamma)*(gamma21-1)+2

    B1 = -(gamma21+1)*((2-Gamma)*(Gamma*gamma21**2+1)+Gamma*(Gamma-1)*gamma21)*sigma
    B2 = -(gamma21-1)*(Gamma*(2-Gamma)*(gamma21**2-2)+(2*gamma21+3))
    B=B1+B2

    C1 = (gamma21+1)*(Gamma*(1-Gamma/4.)*(gamma21**2-1)+1)*sigma**2
    C2 = (gamma21**2-1)*(2*gamma21-(2-Gamma)*(Gamma*gamma21-1))*sigma
    C3 = (gamma21+1)*(gamma21-1)**2*(Gamma-1)**2
    C=C1+C2+C3

    D = -(gamma21-1)*(gamma21+1)**2*(2-Gamma)**2*(sigma**2/4.)
    return A*x**3+B*x**2+C*x+D

def u_downstream_s(gamma1,gamma2,sigma):
    beta1=gamma2beta(gamma1)
    beta2=gamma2beta(gamma2)
    beta21=np.abs(beta2-beta1)/(1-beta2*beta1)
    gamma21=beta2gamma(beta21)
    Gamma=(4*gamma21+1)/3/gamma21
    u_2s_0=np.sqrt((gamma21-1)*(Gamma-1)**2/(Gamma*(2-Gamma)*(gamma21-1)+2))
    
    u_2s_low=1e-2
    u_2s_up=100000.0
    log_u_2s_list=np.arange(np.log10(u_2s_low),np.log10(u_2s_up),1e-3)
    u_2s_list=10**log_u_2s_list
    delta=fgeneral(u_2s_list,gamma21,Gamma,sigma)
    
    u_2s_roots=[]
    for i in range(len(u_2s_list)-1):
        if delta[i]*delta[i+1]<0:
            u_2s_roots.append(u_2s_list[i])
    if sigma>0:
        u_2s_roots=np.array(u_2s_roots)
        if len(u_2s_roots)>0:
            u_2s=u_2s_roots[u_2s_roots>u_2s_0][0]
        else:
            #print('wrong')
            u_2s=u_2s_0
    else:
        u_2s=u_2s_0
    return u_2s

def downstream(gamma1,gamma2,sigma,n1):
    
    beta1=gamma2beta(gamma1)
    beta2=gamma2beta(gamma2)
    beta21=np.abs(beta2-beta1)/(1-beta2*beta1)
    gamma21=beta2gamma(beta21)
    Gamma=(4*gamma21+1)/3/gamma21
    
    u_2s=u_downstream_s(gamma1,gamma2,sigma)
    u_1s=u_2s*gamma21+(u_2s**2+1)**(1/2)*(gamma21**2-1)**(1/2)
    n2=n1*(u_1s/u_2s)
    e2=(n2*mp*ccont**2)*(gamma21-1)*(1-(gamma21+1)/(2*u_1s*u_2s)*sigma)
    p2=(Gamma-1)*e2
    pb2=p2*(1/2/(Gamma-1))*(u_1s/u_2s)*sigma*(e2/n2/mp/ccont**2)**(-1)
    
    return p2,pb2,e2,n2,u_1s


# function to calculate the physical quantities in the blastwaves based on pressure balance
# use the pressure balance assumption to generate initial condition
def BW_params(gamma_w, sigma_w, n_w, gamma_m, sigma_m, n_m, beta_ej_min):
    
    B_w2 = 4*np.pi*n_w*mp*ccont**2 * sigma_w
    B_w = np.sqrt(B_w2)
    
    beta_w = gamma2beta(gamma_w)
    beta_m = gamma2beta(gamma_m)
    
    N_step = 10000
    Gamma_up = gamma_w-0.001
    Gamma_low = beta2gamma(beta_ej_min)
    
    
    for j in range(N_step):
        Gamma_mid = (Gamma_up + Gamma_low)/2
        [p_r_up, p_rb_up, e_r, n_r, u_wrs]= downstream(gamma_w,Gamma_up,sigma_w,n_w)
        [p_f_up, p_fb_up, e_f, n_f, u_mfs]= downstream(gamma_m,Gamma_up,sigma_m,n_m)
    
    
        [p_r_mid, p_rb_mid, e_r, n_r, u_wrs]= downstream(gamma_w,Gamma_mid,sigma_w,n_w)
        [p_f_mid, p_fb_mid, e_f, n_f, u_mfs]= downstream(gamma_m,Gamma_mid,sigma_m,n_m)
        if (p_r_up + p_rb_up - p_f_up)*(p_r_mid + p_rb_mid - p_f_mid) < 0:
            Gamma_low = Gamma_mid
        else:
            Gamma_up = Gamma_mid
        if abs(p_r_mid + p_rb_mid - p_f_mid) < 1e-6*p_f_mid or (Gamma_up - Gamma_low) < 1e-5:
            Gamma = Gamma_up
            beta = gamma2beta(Gamma)
            
            beta_wm = (beta_w - beta_m)/(1-beta_w*beta_m) #??
            Gamma_wm = beta2gamma(beta_wm)
            if sigma_w < 8/3 * Gamma_wm**2 * n_m/n_w:

                p_r = p_r_mid
                p_f = p_f_mid
            
                u_bwrs = u_downstream_s(gamma_w,Gamma,sigma_w)
                u_bwfs = u_downstream_s(gamma_m,Gamma,sigma_m)
                B_r = B_w*(u_wrs/u_bwrs)
                rho_r = n_r*mp
                
                
                h_r = rho_r*ccont**2 + e_r + p_r
                rho_f = n_f*mp
                h_f = rho_f*ccont**2 + e_f + p_f
            
                beta_bwrs = u_bwrs / np.sqrt(1+u_bwrs**2)
                beta_r = (beta - beta_bwrs)/(1-beta*beta_bwrs)
            
                beta_bwfs = u_bwfs / np.sqrt(1+u_bwfs**2)
                beta_f = (beta + beta_bwfs)/(1 + beta*beta_bwfs)
            break
    #print('Gamma = ',Gamma, 'Gamma_low = ', Gamma_low, 'beta_m = ', beta_m)
        
    return Gamma, rho_f, rho_r, p_f, p_r, h_f, h_r, B_r, beta_r, beta_f


def BW_integral_params(Para_w, Para_m, r0, ts):
    Lsd = Para_w[0]
    gamma_w = Para_w[1]
    sigma_w = Para_w[2]
    
    Mej = Para_m[0]
    sigma_m = Para_m[1]
    beta_ej_max = Para_m[2]
    beta_ej_min = Para_m[3]
    alpha = Para_m[4]
    
    r_r = r0
    r_f = r0
    r = r0
    
    v_min = beta_ej_min*ccont
    v_max = beta_ej_max*ccont
    t0 = r0/beta_ej_min/ccont
    t_list = np.logspace(np.log10(t0),np.log10(t0 + ts),10)
    dv = 0.01*ccont
    for i in range(len(t_list)):
        delta_ej = dv * t_list[i]
        dV_ej = 4*np.pi*r_f**2*delta_ej       
        beta_c = r_f/t_list[i]/ccont
        gamma_m = beta2gamma(beta_c)
        if beta_c > beta_ej_max:
            break
        delta_Mej = Mej*(-alpha+3)/(v_max**(-alpha+3) - v_min**(-alpha+3))*(beta_c*ccont)**(-alpha+2)*dv       
        n_m = delta_Mej / dV_ej / mp
        n_w = unshocked_wind(Lsd, gamma_w, r_r, sigma_w)
        [Gamma, rho_f, rho_r, p_f, p_r, h_f, h_r, B_r, beta_r, beta_f] = \
            BW_params(gamma_w, sigma_w, n_w, gamma_m, sigma_m, n_m, beta_ej_min)
        beta = gamma2beta(Gamma)
        
        Sigma_sph = 0
        P_sph = 0
        H_sph = 0
        B_sph = 0
        if i > 0:
            dt = t_list[i] - t_list[i-1]            
            r_r = r_r + beta_r * ccont * dt
            r_f = r_f + beta_f * ccont * dt
            r = r + beta * ccont * dt
            V_ej_s = 4/3 * np.pi * (r_f**3 - r**3)
            V_wind_s = 4/3 * np.pi * (r**3 - r_r**3)
            Sigma_sph = rho_f * V_ej_s + rho_r * V_wind_s
            P_sph = p_f * V_ej_s + p_r * V_wind_s
            H_sph = h_f * V_ej_s + h_r * V_wind_s
            B_sph = B_r**2 * V_wind_s
            
    

    return Sigma_sph, P_sph, H_sph, B_sph, Gamma

if __name__ == '__main__':      
    r0 = 1e9
    ts = 0.1
    Lsd = 1.0e45
    sigma_w = 10000
    gamma_w = 1000
    Para_w = [Lsd, gamma_w, sigma_w]
    
    Mej = 1e-2*Msun
    beta_ej_min = 0.05
    beta_ej_max = 0.2
    alpha = 3.01
    sigma_m = 0
    Para_m = [Mej, sigma_m, beta_ej_max, beta_ej_min, alpha]
    
    Results = BW_integral_params(Para_w, Para_m, r0, ts)
    Gamma = Results[4]
    beta = np.sqrt(1 - 1/Gamma**2)
    print('beta = ', beta)



