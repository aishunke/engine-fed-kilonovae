This code is produced to calculate the engine-fed kilonova (a post-merger magnetar as a long-lasting central engine).


### Dynamics: magnetar wind - merger ejecta interaction (Ai et al. 2022, MNRAS, 516,2614).

#  A forward shock - reverse shock system is generated. The dynamics of this system is based on the dynamical model for (relativistic magnetized) blastwaves. (Ai & Zhang. 2021, MNRAS, 507,1788)


### Radiation: embeded into the dynamics (Ai et al. 2024, arXiv: 2405.00638). 

# Heating: radioactive heating, shock heating, X-ray irradiation (from magnetar wind)

# cooling: adiabatic expansion, thermal radiation

# photon diffusion: diffuse across different ejecta shells, inside the ejecta.


### structure of the code

# Input: There are two distinct types of input files, contained in two separate folders: "Input" and "Input_mp". When calculating for a single parameter set, one can directly edit the "input.txt" file located under the "Input" folder. When performing multi-process calculations (for a series of parameter sets), one should edit the "input_main.txt" file in the "Input_mp" folder. Remember to change "multiinputs = False" to "multiinputs = True" when conducting multi-process calculations.

# band.py: The information of observational bands, can be called.

# mechanical_model.py: The core to model the dynamics and radiation.

# mechanical_model_initial_condition.py: Generate an appropriate initial condition for the mechanical model for blastwaves. 

# main.py: read the input files and set up the resolution


### run the code

# The code is written with Python. Run the code simply by typing "python3 main.py" in the Terminal. 


### Output (The files are named with the parameter set used to generate this output file)

# For the output related to dynamics (Folder "Results_dynamics"),  it includes the time sequence of: four velocity of the blast wave; positions of the forward shock (r_f), reverse shock (r_r) and the contact discontinuity (r)

# For the output related to radiation (Folder "Results_radiation"), it includes the evolution of the bolometric luminosity of engine-fed kilonova, as well as the multi-band luminosities. 


For details, see the comments in each code file. 




