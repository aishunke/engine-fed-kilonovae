#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 13:32:57 2023

@author: shunkeai
"""

import numpy as np
from mechanical_model import *
import time
import os
import multiprocessing as mp


tstart = time.time()
####### constant #######
ccont=2.99*10**10
m_p=1.67352e-24
Msun = 2.0e33
a = 7.5657e-15
h = 6.63e-27
kb=1.38*10**(-23)*10**7
sigmaT=6.652*10**(-25)
sigmaB=5.670373*10**(-5)
pi=np.pi

# function to read the input file for multithreading calculation
def generate_input_mp(path):
    f = open(path+'/input_main.txt','r')
    Inputs_raw = f.readlines()
    Inputs = {}
    for i in range(len(Inputs_raw)):
         Input = split(Inputs_raw[i])
         Inputs[Input[0]] = np.linspace(float(Input[1]),float(Input[2]),int(Input[3]))
    f.close()

    M_ej_sun_array = Inputs.get('M_ej_sun')
    beta_min_array = Inputs.get('beta_min')
    beta_max_array = Inputs.get('beta_max')
    alpha_array = Inputs.get('alpha')
    kappa_array = Inputs.get('kappa')
    Lsd_0_array = 10**np.array(Inputs.get('Lsd_0'))
    E_rot_array = 10**np.array(Inputs.get('E_rot'))
    xi_sd_x_array = Inputs.get('xi_sd_x')
    
    file_number = 0
    for i in range(len(M_ej_sun_array)):
        for j in range(len(beta_min_array)):
            for k in range(len(beta_max_array)):
                for l in range(len(alpha_array)):
                    for m in range(len(kappa_array)):
                        for n in range(len(Lsd_0_array)):
                            for o in range(len(E_rot_array)):
                                for p in range(len(xi_sd_x_array)):
                                    str_M_ej_sun = "{:.2e}".format(M_ej_sun_array[i])
                                    str_beta_min = "{:.2e}".format(beta_min_array[j])
                                    str_beta_max = "{:.2e}".format(beta_max_array[k])
                                    str_alpha = "{:.2e}".format(alpha_array[l])
                                    str_kappa = "{:.2e}".format(kappa_array[m])
                                    str_Lsd_0 = "{:.2e}".format(Lsd_0_array[n])
                                    str_E_rot = "{:.2e}".format(E_rot_array[o])
                                    str_xi_sd_x = "{:.2e}".format(xi_sd_x_array[p])
                                    
                                    filename = 'input_process'+str(file_number)+'.txt'
                                    f1 = open(path+'/'+filename,'w')
                                    f1.write('M_ej_sun='+str_M_ej_sun+'\n')
                                    f1.write('beta_min='+str_beta_min+'\n')
                                    f1.write('beta_max='+str_beta_max+'\n')
                                    f1.write('alpha='+str_alpha+'\n')
                                    f1.write('kappa='+str_kappa+'\n')
                                    f1.write('Lsd_0='+str_Lsd_0+'\n')
                                    f1.write('E_rot='+str_E_rot+'\n')
                                    f1.write('xi_sd_x='+str_xi_sd_x)
                                    f1.close()
                                    file_number = file_number + 1
                                    
    
    return True

# split a random string. "ask" represents a random string. My name is ask.  
def split(ask): 
    output=[]
    output1=''
    
    for i in range(len(ask)):
        digit=ask[i]
        if digit ==' ' or digit=='\t' or digit=='=' or digit==':' : 
            if len(output1)>0:
                output.append(output1)
            output1=''
            continue
        if digit == '\n':
            output.append(output1)
            output1=''
            break
        else: 
            if i == len(ask)-1:
                output1+=digit
                output.append(output1)            
        output1+=digit
    return output


def job(Input_filename):        
    f = open(Input_filename,'r')
    Inputs_raw = f.readlines()
    Inputs = {}
    for i in range(len(Inputs_raw)):
         Input = split(Inputs_raw[i])
         Inputs[Input[0]] = float(Input[1])




    M_ej_sun = Inputs.get('M_ej_sun')
    beta_min = Inputs.get('beta_min')
    beta_max = Inputs.get('beta_max')
    alpha = Inputs.get('alpha')
    kappa = Inputs.get('kappa')
    Lsd_0 = Inputs.get('Lsd_0')
    E_rot = Inputs.get('E_rot')
    xi_sd_x = Inputs.get('xi_sd_x')
    
    str_M_ej_sun = "{:.2e}".format(M_ej_sun)
    str_Lsd_0 = "{:.2e}".format(Lsd_0)
    str_kappa = "{:.2e}".format(kappa)
    str_E_rot = "{:.2e}".format(E_rot)
    str_xi_sd_x = "{:.2e}".format(xi_sd_x)
    
    Output_file_name = 'Lsd_'+str_Lsd_0+'_E_rot_'+str_E_rot+'_kappa_'+str_kappa+'_M_ej_'+str_M_ej_sun+'_Lx'+str_xi_sd_x+'_ht.txt'   
    M_ej = M_ej_sun*Msun
    t0 = 1.0 # time for the first wind-ejecta interaction
    N_dbeta = 100 # spacial resolution (number of shells for the ejecta)
    N_dbeta_max = 80000 # maximum resolution
    
    # this module can automatically increase the spacial resolution if it was too low
    while N_dbeta <= N_dbeta_max:
        results = mechanical_model_loop(Lsd_0, E_rot, M_ej, kappa, beta_min, beta_max, alpha, N_dbeta, t0, N_dbeta_max, Output_file_name, xi_sd_x)
        if len(results) == 2:
            N_dbeta = N_dbeta * 3
        elif len(results) == 1:
            N_dbeta_max = N_dbeta_max * 2
            N_dbeta = N_dbeta_max
            continue
        else:
            break
    if (N_dbeta > N_dbeta_max) and (len(results) <= 2):
        results = mechanical_model_loop(Lsd_0, E_rot, M_ej, kappa, beta_min, beta_max, alpha, N_dbeta, t0, N_dbeta_max, Output_file_name, xi_sd_x)
        
    


if __name__ == '__main__':  
    
    multiinputs = False # a switch to turn on/turn off the multithreading calculation
    
    if multiinputs == False:
        path = r"Inputs/Input"
        f = os.walk(path)
        for dirpath,dirnames,filenames in f:
            pass
        filename = path + '/' + filenames[0]
        res = job(filename)
    if multiinputs == True:
        path = r"Inputs/Input_mp"
        Return = generate_input_mp(path)
        
        f = os.walk(path)
        for dirpath,dirnames,filenames in f:
            pass
        filename_list = []
        for i in range(len(filenames)):
            if filenames[i][-4:] == '.txt' and filenames[i][-5].isdigit():
                filename_list.append(path + '/' + filenames[i])
        print(filename_list)
        pool = mp.Pool(processes = min([len(filename_list),4]))
        res = pool.map(job,filename_list)
        
tend = time.time()

print('duration = ', tend - tstart)
